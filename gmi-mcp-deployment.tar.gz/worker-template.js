// GMI Handbók Worker - Static HTML Server
// Embedded content fyrir gmi.eyjar.app

// HTML content embedded í Worker
const PAGES = {
  '/': `<!-- index.html content -->`,
  '/index.html': `<!-- index.html content -->`,
  '/skref1.html': `<!-- skref1.html content -->`,
  '/skref2.html': `<!-- skref2.html content -->`,
  '/skref3.html': `<!-- skref3.html content -->`,
  '/skref4.html': `<!-- skref4.html content -->`,
};

export default {
  async fetch(request) {
    const url = new URL(request.url);
    let pathname = url.pathname;
    
    // Redirect root til index.html
    if (pathname === '/') {
      pathname = '/index.html';
    }
    
    // Athuga hvort við höfum þessa síðu
    const content = PAGES[pathname];
    
    if (content) {
      return new Response(content, {
        headers: {
          'Content-Type': 'text/html;charset=UTF-8',
          'Cache-Control': 'public, max-age=3600',
          'X-Content-Type-Options': 'nosniff',
        },
      });
    }
    
    // 404 ef síða finnst ekki
    return new Response('404 Not Found', {
      status: 404,
      headers: {
        'Content-Type': 'text/plain',
      },
    });
  },
};
