// GMI Handbók Worker - Serves static HTML assets
export default {
  async fetch(request, env) {
    // Serve static assets directly using ASSETS binding
    return env.ASSETS.fetch(request);
  }
}
