#!/bin/bash

# GMI Handbók - Cloudflare Pages Deployment Script
# Notað með Wrangler CLI

echo "🚀 GMI Handbók - Cloudflare Deployment"
echo "======================================"
echo ""

# Check if wrangler is installed
if ! command -v wrangler &> /dev/null; then
    echo "⚠️  Wrangler er ekki uppsett."
    echo "Setja upp með: npm install -g wrangler"
    echo ""
    read -p "Viltu setja upp wrangler núna? (y/n) " -n 1 -r
    echo ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        npm install -g wrangler
    else
        echo "❌ Deployment hætt við."
        exit 1
    fi
fi

# Login check
echo "🔐 Athuga Cloudflare login..."
if ! wrangler whoami &> /dev/null; then
    echo "Þú þarft að login."
    wrangler login
fi

# Navigate to project directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo ""
echo "📦 Project Directory: $SCRIPT_DIR"
echo ""

# Create wrangler.toml if doesn't exist
if [ ! -f "wrangler.toml" ]; then
    echo "📝 Búa til wrangler.toml..."
    cat > wrangler.toml << 'EOF'
name = "gmi-handbook"
compatibility_date = "2025-10-03"
account_id = "58af5443cdcb04b408dd29002ced60df"

[assets]
directory = "./public"

[[routes]]
pattern = "gmi.eyjar.app/*"
custom_domain = true
EOF
    echo "✅ wrangler.toml búið til"
fi

# Deploy
echo ""
echo "🚀 Deploying til Cloudflare..."
echo ""

wrangler pages deploy public --project-name=gmi-handbook

# Check if deployment was successful
if [ $? -eq 0 ]; then
    echo ""
    echo "✅ ======================================"
    echo "✅  DEPLOYMENT TÓKST!"
    echo "✅ ======================================"
    echo ""
    echo "🌐 Aðgangur:"
    echo "   - Pages.dev: https://gmi-handbook.pages.dev"
    echo "   - Custom: https://gmi.eyjar.app (eftir DNS setup)"
    echo ""
    echo "📝 Næstu skref:"
    echo "   1. Test síðuna: https://gmi-handbook.pages.dev"
    echo "   2. Set up custom domain í Cloudflare Dashboard"
    echo "   3. Share með teyminu!"
    echo ""
else
    echo ""
    echo "❌ Deployment mistókst"
    echo "Athugaðu error messages hér að ofan"
    exit 1
fi
