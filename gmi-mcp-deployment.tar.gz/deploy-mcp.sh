#!/bin/bash

# GMI Handbók - MCP Cloudflare Deployment
# Uses Cloudflare MCP setup + Wrangler deployment

set -e

echo "🚀 GMI Handbók - MCP Cloudflare Deployment"
echo "=========================================="
echo ""

# MCP Configuration (already set via MCP)
ACCOUNT_ID="58af5443cdcb04b408dd29002ced60df"
KV_NAMESPACE_ID="1b7738dda4cc4d23a423bb9157d12c6b"
PROJECT_NAME="gmi-handbook"

echo "✅ MCP Configuration:"
echo "   Account ID: $ACCOUNT_ID"
echo "   KV Namespace: $KV_NAMESPACE_ID"  
echo "   Project: $PROJECT_NAME"
echo ""

# Check for wrangler
if ! command -v wrangler &> /dev/null; then
    echo "📦 Installing Wrangler CLI..."
    npm install -g wrangler
fi

# Check if logged in
echo "🔐 Checking Cloudflare authentication..."
if ! wrangler whoami &> /dev/null; then
    echo "Please login to Cloudflare:"
    wrangler login
fi

echo ""
echo "✅ Authenticated with Cloudflare"
echo ""

# Deploy Worker with static assets
echo "🚀 Deploying Worker with static assets..."
echo ""

wrangler deploy \
  --name "$PROJECT_NAME" \
  --compatibility-date "2025-10-03" \
  --assets ./public \
  --env production

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ ============================================"
    echo "✅  DEPLOYMENT SUCCESSFUL!"
    echo "✅ ============================================"
    echo ""
    echo "🌐 Your site is live at:"
    echo "   https://gmi-handbook.omar-vertis.workers.dev"
    echo ""
    echo "📝 Next steps:"
    echo "   1. Test: curl -I https://gmi-handbook.omar-vertis.workers.dev"
    echo "   2. Set up custom domain: gmi.eyjar.app"
    echo "   3. Share with team!"
    echo ""
    echo "🔧 Custom Domain Setup:"
    echo "   wrangler domains add gmi.eyjar.app"
    echo ""
else
    echo ""
    echo "❌ Deployment failed"
    echo "Check error messages above"
    exit 1
fi
