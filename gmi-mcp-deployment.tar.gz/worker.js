// GMI Handbók Worker - Serves all static pages
export default {
  async fetch(request) {
    const url = new URL(request.url);
    const path = url.pathname;
    
    // Route mapping
    const routes = {
      '/': '/index.html',
      '/index.html': '/index.html',
      '/skref1.html': '/skref1.html',
      '/skref1': '/skref1.html',
      '/skref2.html': '/skref2.html',
      '/skref2': '/skref2.html',
      '/skref3.html': '/skref3.html',
      '/skref3': '/skref3.html',
      '/skref4.html': '/skref4.html',
      '/skref4': '/skref4.html',
    };
    
    const targetPath = routes[path];
    
    if (targetPath) {
      // Fetch from KV or return from embedded content
      try {
        // Try KV first
        const content = await GMI_CONTENT.get(targetPath);
        if (content) {
          return new Response(content, {
            headers: {
              'Content-Type': 'text/html;charset=UTF-8',
              'Cache-Control': 'public, max-age=3600',
            },
          });
        }
      } catch (e) {
        // KV not available, serve 404
      }
    }
    
    // 404
    return new Response('404 Not Found - GMI Handbók', {
      status: 404,
      headers: { 'Content-Type': 'text/plain' },
    });
  },
};
