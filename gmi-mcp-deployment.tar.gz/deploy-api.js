#!/usr/bin/env node

/**
 * GMI Handbók - Automated Cloudflare Pages Deployment
 * Notað með Cloudflare API til að deploy beint
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

const CONFIG = {
  accountId: '58af5443cdcb04b408dd29002ced60df',
  projectName: 'gmi-handbook',
  apiToken: process.env.CLOUDFLARE_API_TOKEN,
};

async function deployToCloudflare() {
  console.log('🚀 GMI Handbók - Cloudflare Pages Deployment');
  console.log('='.repeat(50));
  console.log('');

  // Check fyrir API token
  if (!CONFIG.apiToken) {
    console.error('❌ CLOUDFLARE_API_TOKEN environment variable vantar!');
    console.log('');
    console.log('Setja upp:');
    console.log('  1. Fara á Cloudflare Dashboard → My Profile → API Tokens');
    console.log('  2. Create Token með "Edit Cloudflare Workers" template');
    console.log('  3. Export CLOUDFLARE_API_TOKEN=<your-token>');
    console.log('  4. Run þetta script aftur');
    console.log('');
    process.exit(1);
  }

  console.log('✅ API Token fundið');
  console.log('📦 Account ID:', CONFIG.accountId);
  console.log('📝 Project:', CONFIG.projectName);
  console.log('');

  // Read HTML files
  const publicDir = path.join(__dirname, 'public');
  const files = fs.readdirSync(publicDir);
  
  console.log('📄 HTML Files:');
  files.forEach(file => {
    const size = fs.statSync(path.join(publicDir, file)).size;
    console.log(`   - ${file} (${(size/1024).toFixed(1)}KB)`);
  });
  console.log('');

  // Create deployment
  console.log('🚀 Deploying til Cloudflare Pages...');
  console.log('');
  
  // Nota Wrangler Pages API
  const FormData = require('form-data');
  const form = new FormData();
  
  files.forEach(file => {
    const filePath = path.join(publicDir, file);
    form.append('file', fs.createReadStream(filePath), file);
  });

  const options = {
    method: 'POST',
    hostname: 'api.cloudflare.com',
    path: `/client/v4/accounts/${CONFIG.accountId}/pages/projects/${CONFIG.projectName}/deployments`,
    headers: {
      'Authorization': `Bearer ${CONFIG.apiToken}`,
      ...form.getHeaders(),
    },
  };

  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        if (res.statusCode === 200 || res.statusCode === 201) {
          const result = JSON.parse(data);
          console.log('✅ Deployment tókst!');
          console.log('');
          console.log('🌐 Aðgangur:');
          console.log(`   - Pages.dev: https://${CONFIG.projectName}.pages.dev`);
          console.log(`   - Custom: https://gmi.eyjar.app (eftir DNS)`);
          console.log('');
          resolve(result);
        } else {
          console.error('❌ Deployment mistókst:', res.statusCode);
          console.error(data);
          reject(new Error(data));
        }
      });
    });
    
    req.on('error', reject);
    form.pipe(req);
  });
}

// Run deployment
if (require.main === module) {
  deployToCloudflare()
    .then(() => {
      console.log('✅ Allt í lagi!');
      process.exit(0);
    })
    .catch((err) => {
      console.error('❌ Error:', err.message);
      process.exit(1);
    });
}

module.exports = { deployToCloudflare };
