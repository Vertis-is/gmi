// GMI Handbók - Cloudflare Worker
// Serves static HTML files for the GMI (Graded Motor Imagery) handbook

import { getAssetFromKV } from '@cloudflare/kv-asset-handler';

addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request));
});

async function handleRequest(request) {
  const url = new URL(request.url);
  
  try {
    // Serve static assets from KV
    const response = await getAssetFromKV(event, {
      mapRequestToAsset: req => {
        const url = new URL(req.url);
        
        // Handle root path
        if (url.pathname === '/') {
          url.pathname = '/index.html';
        }
        
        // Handle paths without .html extension
        if (!url.pathname.includes('.') && !url.pathname.endsWith('/')) {
          url.pathname = url.pathname + '.html';
        }
        
        return new Request(url.toString(), req);
      },
    });

    // Add security headers
    const headers = new Headers(response.headers);
    headers.set('X-Content-Type-Options', 'nosniff');
    headers.set('X-Frame-Options', 'SAMEORIGIN');
    headers.set('X-XSS-Protection', '1; mode=block');
    headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
    
    return new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers,
    });
    
  } catch (error) {
    // If asset not found, return 404
    return new Response('404 Not Found', {
      status: 404,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
      },
    });
  }
}
